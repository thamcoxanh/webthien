<?php /* /Users/apple/lavarel/thienv1/resources/views/admin/category_admin_manager.blade.php */ ?>
<?php $__env->startSection('content'); ?>

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                            Manager Category
                        </h2>
                    </div>
                    <div class="body">
                        <table id="mainTable" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>name</th>
                                    <th>description</th>
                                    <th>Parent Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $allUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>


                                           <td><?php echo e($p['name']); ?></td>
                                           <td><?php echo e($p['description']); ?></td>
                                           <td><?php echo e($p['parent_name']); ?></td>
                                           <td>
                                               <a onclick="javascript:delete_confirm(<?php echo e($p['id']); ?>);" href="#">
                                                   <i class="material-icons">delete</i>
                                               </a>
                                               <a href="/admin/category-update/<?php echo e($p['id']); ?>">
                                                   <i class="material-icons">mode_edit</i>
                                               </a>
                                           </td>

                                  </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
<script>
    function delete_confirm(id){

        var r = confirm("Do you want delete this Category ?");
        if (r == true) {
            url = '/admin/category-delete/'+id;
            $(location).attr("href", url);
        }

    }
</script>
<?php echo e($paginator->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>