<?php /* /Users/apple/lavarel/thienv1/resources/views/admin.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="card">
        <div class="header">
            <h2>Thống kê các tuần trong năm <?php echo e($title_year); ?></h2>
        </div>
        <div class="body">
            <div id="bar_chart" class="graph"></div>
        </div>
    </div>
    <div class="card">
        <div class="header">
            <h2>Thống kê các tháng trong năm <?php echo e($title_year); ?></h2>

        </div>
        <div class="body">
            <div id="bar_chart_month" class="graph"></div>
        </div>
    </div>
    <div class="card">
        <div class="header">
            <h2>Thống kê các tuần trong năm <?php echo e($title_year_old); ?></h2>

        </div>
        <div class="body">
            <div id="bar_chart_old" class="graph"></div>
        </div>
    </div>
    <div class="card">
        <div class="header">
            <h2>Thống kê các tháng trong năm <?php echo e($title_year); ?></h2>

        </div>
        <div class="body">
            <div id="bar_chart_month_old" class="graph"></div>
        </div>
    </div>
</div>
<script>
$(function () {
    Morris.Bar({
        element: 'bar_chart',
        data: [
            <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            {
                x: 'Tuần <?php echo e($p["week"]); ?> : <?php echo e($p["week_start"]); ?> - <?php echo e($p["week_end"]); ?>',
                y: '<?php echo e($p["price"]); ?>',
            },
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        ],
        xkey: 'x',
        ykeys: ['y'],
        labels: ['Y'],
        barColors: ['rgb(233, 30, 99)', 'rgb(0, 188, 212)', 'rgb(0, 150, 136)'],
    });

    Morris.Bar({
        element: 'bar_chart_old',
        data: [
            <?php $__currentLoopData = $year_old; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            {
                x: 'Tuần <?php echo e($p["week"]); ?> : <?php echo e($p["week_start"]); ?> - <?php echo e($p["week_end"]); ?>',
                y: '<?php echo e($p["price"]); ?>',
            },
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        ],
        xkey: 'x',
        ykeys: ['y'],
        labels: ['Y'],
        barColors: ['rgb(233, 30, 99)', 'rgb(0, 188, 212)', 'rgb(0, 150, 136)'],
    });

    Morris.Bar({
        element: 'bar_chart_month',
        data: [
            <?php $__currentLoopData = $month_year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            {
                x: 'Tháng <?php echo e($p["month"]); ?> : <?php echo e($p["week_start"]); ?> - <?php echo e($p["week_end"]); ?>',
                y: '<?php echo e($p["price"]); ?>',
            },
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        ],
        xkey: 'x',
        ykeys: ['y'],
        labels: ['Y'],
        barColors: ['rgb(233, 30, 99)', 'rgb(0, 188, 212)', 'rgb(0, 150, 136)'],
    });
    Morris.Bar({
        element: 'bar_chart_month_old',
        data: [
            <?php $__currentLoopData = $month_year_old; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            {
                x: 'Tháng <?php echo e($p["month"]); ?> : <?php echo e($p["week_start"]); ?> - <?php echo e($p["week_end"]); ?>',
                y: '<?php echo e($p["price"]); ?>',
            },
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        ],
        xkey: 'x',
        ykeys: ['y'],
        labels: ['Y'],
        barColors: ['rgb(233, 30, 99)', 'rgb(0, 188, 212)', 'rgb(0, 150, 136)'],
    });
});



</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>