<?php /* /Users/apple/lavarel/thienv1/resources/views/admin/user_admin_manager.blade.php */ ?>
<?php $__env->startSection('content'); ?>

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                            Manager User
                        </h2>
                    </div>
                    <div class="body">
                        <table id="mainTable" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>name</th>
                                    <th>email</th>
                                    <th>type</th>
                                    <th>service</th>
                                    <th>address</th>
                                    <th>phone</th>
                                    <th>price</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $allUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>


                                           <td><?php echo e($p['name']); ?></td>
                                           <td><?php echo e($p['email']); ?></td>
                                           <td><?php echo e($p['type']); ?></td>
                                           <td><?php echo e($p['service']); ?></td>
                                           <td><?php echo e($p['address']); ?></td>
                                           <td><?php echo e($p['phone']); ?></td>
                                           <td><?php echo e($p['price']); ?></td>
                                           <td>
                                               <a onclick="javascript:delete_confirm(<?php echo e($p['id']); ?>);" href="#">
                                                   <i class="material-icons">delete</i>
                                               </a>
                                               <a href="/admin/user-update/<?php echo e($p['id']); ?>">
                                                   <i class="material-icons">mode_edit</i>
                                               </a>
                                           </td>

                                  </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
<script>
    function delete_confirm(id){

        var r = confirm("Do you want delete this User ?");
        if (r == true) {
            url = '/admin/user-delete/'+id;
            $(location).attr("href", url);
        }

    }
</script>
<?php echo e($paginator->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>